// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lint against policy pack"); }
int main(){
  announce();
  return lionss_run_workload("k8s-manifest-lint");
}
