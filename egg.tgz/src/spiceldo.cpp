// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Transient 0-2 ms");
  std::fflush(stdout);
  return lionss_run_workload("spiceldo");
}
