// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("EKF attitude estimate"); }
int main(){
  announce();
  return lionss_run_workload("quadrotor_ekf");
}
