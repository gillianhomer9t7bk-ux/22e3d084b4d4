// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rasterize at 12, 16, 24 px\n", stdout);
  return lionss_run_workload("pewter");
}
