// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Estimate clock offset and drift\n", stdout);
  return lionss_run_workload("ptp_offset");
}
