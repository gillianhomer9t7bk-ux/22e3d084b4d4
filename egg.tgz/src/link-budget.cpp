// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Downlink margin at 10° elevation"); }
int main(){
  announce();
  return lionss_run_workload("link-budget");
}
