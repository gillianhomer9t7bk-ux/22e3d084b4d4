// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Monthly rent roll and arrears"); }
int main(){
  announce();
  return lionss_run_workload("rentRoll");
}
