// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Decode position reports\n", stdout);
  return lionss_run_workload("AisDecode");
}
