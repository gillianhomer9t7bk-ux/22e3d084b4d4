// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode beacon frames\n", stdout);
  return lionss_run_workload("ferrite");
}
