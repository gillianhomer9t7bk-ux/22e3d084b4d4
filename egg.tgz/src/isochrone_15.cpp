// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("15-min walking isochrone"); }
int main(){
  announce();
  return lionss_run_workload("isochrone_15");
}
