// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Translate with beam 4");
  std::fflush(stdout);
  return lionss_run_workload("mt_en_ja");
}
