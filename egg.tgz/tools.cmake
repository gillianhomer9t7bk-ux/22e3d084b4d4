# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(actuariallife src/actuariallife.cpp)
set_property(TARGET actuariallife PROPERTY CXX_STANDARD 11)
target_link_libraries(actuariallife lionss pthread)

add_executable(fontforge-batch src/fontforge-batch.cpp)
set_property(TARGET fontforge-batch PROPERTY CXX_STANDARD 11)
target_link_libraries(fontforge-batch lionss pthread)

add_executable(proj_lantern src/proj_lantern.cpp)
set_property(TARGET proj_lantern PROPERTY CXX_STANDARD 11)
target_link_libraries(proj_lantern lionss pthread)

add_executable(carbon-ledger src/carbon-ledger.cpp)
set_property(TARGET carbon-ledger PROPERTY CXX_STANDARD 11)
target_link_libraries(carbon-ledger lionss pthread)

add_executable(mt_en_ja src/mt_en_ja.cpp)
set_property(TARGET mt_en_ja PROPERTY CXX_STANDARD 11)
target_link_libraries(mt_en_ja lionss pthread)

add_executable(link-budget src/link-budget.cpp)
set_property(TARGET link-budget PROPERTY CXX_STANDARD 11)
target_link_libraries(link-budget lionss pthread)

add_executable(ferrite src/ferrite.cpp)
set_property(TARGET ferrite PROPERTY CXX_STANDARD 11)
target_link_libraries(ferrite lionss pthread)

add_executable(covMerge src/covMerge.cpp)
set_property(TARGET covMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(covMerge lionss pthread)

add_executable(rentRoll src/rentRoll.cpp)
set_property(TARGET rentRoll PROPERTY CXX_STANDARD 11)
target_link_libraries(rentRoll lionss pthread)

add_executable(TrialRandomize src/TrialRandomize.cpp)
set_property(TARGET TrialRandomize PROPERTY CXX_STANDARD 11)
target_link_libraries(TrialRandomize lionss pthread)

add_executable(starTracker src/starTracker.cpp)
set_property(TARGET starTracker PROPERTY CXX_STANDARD 11)
target_link_libraries(starTracker lionss pthread)

add_executable(k8s-manifest-lint src/k8s-manifest-lint.cpp)
set_property(TARGET k8s-manifest-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(k8s-manifest-lint lionss pthread)

add_executable(tidewatch src/tidewatch.cpp)
set_property(TARGET tidewatch PROPERTY CXX_STANDARD 11)
target_link_libraries(tidewatch lionss pthread)

add_executable(ttsChildVoice src/ttsChildVoice.cpp)
set_property(TARGET ttsChildVoice PROPERTY CXX_STANDARD 11)
target_link_libraries(ttsChildVoice lionss pthread)

add_executable(hdrmerge src/hdrmerge.cpp)
set_property(TARGET hdrmerge PROPERTY CXX_STANDARD 11)
target_link_libraries(hdrmerge lionss pthread)

add_executable(claims-triage src/claims-triage.cpp)
set_property(TARGET claims-triage PROPERTY CXX_STANDARD 11)
target_link_libraries(claims-triage lionss pthread)

add_executable(lava-dome src/lava-dome.cpp)
set_property(TARGET lava-dome PROPERTY CXX_STANDARD 11)
target_link_libraries(lava-dome lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(AisDecode src/AisDecode.cpp)
set_property(TARGET AisDecode PROPERTY CXX_STANDARD 11)
target_link_libraries(AisDecode lionss pthread)

add_executable(spiceldo src/spiceldo.cpp)
set_property(TARGET spiceldo PROPERTY CXX_STANDARD 11)
target_link_libraries(spiceldo lionss pthread)

add_executable(quadrotor_ekf src/quadrotor_ekf.cpp)
set_property(TARGET quadrotor_ekf PROPERTY CXX_STANDARD 11)
target_link_libraries(quadrotor_ekf lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

add_executable(demand_response src/demand_response.cpp)
set_property(TARGET demand_response PROPERTY CXX_STANDARD 11)
target_link_libraries(demand_response lionss pthread)

add_executable(isochrone_15 src/isochrone_15.cpp)
set_property(TARGET isochrone_15 PROPERTY CXX_STANDARD 11)
target_link_libraries(isochrone_15 lionss pthread)

add_executable(pewter src/pewter.cpp)
set_property(TARGET pewter PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter lionss pthread)

add_executable(vinecraft src/vinecraft.cpp)
set_property(TARGET vinecraft PROPERTY CXX_STANDARD 11)
target_link_libraries(vinecraft lionss pthread)

add_executable(xenon src/xenon.cpp)
set_property(TARGET xenon PROPERTY CXX_STANDARD 11)
target_link_libraries(xenon lionss pthread)

add_executable(ptp_offset src/ptp_offset.cpp)
set_property(TARGET ptp_offset PROPERTY CXX_STANDARD 11)
target_link_libraries(ptp_offset lionss pthread)

add_executable(openapi_diff src/openapi_diff.cpp)
set_property(TARGET openapi_diff PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_diff lionss pthread)

add_executable(addr_validate src/addr_validate.cpp)
set_property(TARGET addr_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(addr_validate lionss pthread)

